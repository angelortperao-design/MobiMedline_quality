Nombre del Equipo: Los Desvelados
Nombre del Programador: Aguilar Ruiz Giovanny
Matricula: 23-003-2053
Correo electrónico: giovanny.aguilar.ruiz@estudiantxs.uacm.edu.mx
		    aguilargiovanny229@gmail.com
Celular: 5583988781